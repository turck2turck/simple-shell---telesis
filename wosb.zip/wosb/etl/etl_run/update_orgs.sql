UPDATE etl.organizations set folder_name = md5(duns_number||'_'||tax_identifier||'_'||tax_identifier_type);
