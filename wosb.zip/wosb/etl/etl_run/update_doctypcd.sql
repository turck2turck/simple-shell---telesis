UPDATE etl.select_recs SET doctypcd = 32 where doctypcd is NULL;

UPDATE etl.select_recs SET doctypcd = ( select target_doctypcd from etl.doc_type_crosswalk where select_recs.doctypcd = doc_type_crosswalk.source_doctypcd) where doctypcd <> NULL; 
