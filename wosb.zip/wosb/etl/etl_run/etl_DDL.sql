-- To drop the tables if desired.

DROP TABLE etl.doc_type_crosswalk ;
DROP TABLE etl.select_recs ;
DROP TABLE etl.organizations ;
DROP TABLE etl.documents ;

-- doc_type_crosswalk. Used to Map new document type to legacy document types.
-- Mapping provided by business at the time of conversion.

CREATE TABLE etl.doc_type_crosswalk
(
  target_doctypcd integer,
  target_doctypdesctxt text,
  source_doctypdesctxt text,
  source_doctypcd integer
--)
--WITH (
  --OIDS=FALSE
);

-- select_recs. Temporary table required for etl processing.

CREATE TABLE etl.select_recs
(
       IMUSERBUSEINSSNIND char(3),
       IMUSERBUSTAXID char(9),
       IMUSERBUSLOCDUNSNMB char(9),
       ORGANIZATION_ID INTEGER, 
       FOLDER_NAME TEXT,
       LEGAL_BUSINESS_NAME TEXT,
       DOCID integer,
       DOCDATA text,
       DOCDATA_PDF text,
       CREATDT timestamp without time zone,
       LASTUPDDT timestamp without time zone,
       DOCNM TEXT,
       DOCTYPCD integer
);

-- Creating Organizations Table

CREATE TABLE etl.organizations 
(
    id serial NOT NULL,
    duns_number character varying NOT NULL,
    tax_identifier character varying NOT NULL,
    tax_identifier_type character varying NOT NULL,
    business_type TEXT DEFAULT 'Unknown' ,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    folder_name text
);


-- Creating Documents Table

CREATE TABLE etl.documents 
(
    id serial NOT NULL,
    organization_id integer,
    stored_file_name text,
    original_file_name text,
    document_type_id integer,
    file_metadata json,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    comment text,
    is_active boolean NOT NULL,
    av_status text NOT NULL,
    valid_pdf boolean
);

