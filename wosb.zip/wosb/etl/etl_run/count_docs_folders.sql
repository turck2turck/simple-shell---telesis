select o.folder_name,  count(*) from etl.documents d, etl.organizations o where d.organization_id = o.id group by o.folder_name;
