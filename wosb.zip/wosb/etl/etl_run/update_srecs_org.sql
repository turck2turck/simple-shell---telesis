update etl.select_recs
set ORGANIZATION_ID = (select id from etl.organizations where select_recs.imuserbuslocdunsnmb = duns_number and select_recs.imuserbustaxid = tax_identifier) 

WHERE 1=1
