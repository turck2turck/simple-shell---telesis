 \COPY sbaone.documents FROM '/data/prod/wosb/etl/etl_data/documents.txt' WITH DELIMITER AS '|' NULL as ''
