INSERT INTO etl.organizations
(duns_number,tax_identifier, tax_identifier_type,  created_at, updated_at) 
(select distinct
imuserbuslocdunsnmb, imuserbustaxid, imuserbuseinssnind, current_date, current_date
FROM etl.select_recs
);
