 \COPY etl.documents to '/data/prod/wosb/etl/etl_data/documents.txt' WITH DELIMITER AS '|' NULL as ''
