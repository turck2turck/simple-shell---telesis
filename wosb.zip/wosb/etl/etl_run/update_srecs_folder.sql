update etl.select_recs
set FOLDER_NAME = (select folder_name from etl.organizations where select_recs.imuserbuslocdunsnmb = duns_number and select_recs.imuserbustaxid = tax_identifier) 

WHERE 1=1
