insert into etl.documents (
  organization_id ,
  stored_file_name,
  original_file_name,
  document_type_id ,
  created_at ,
  updated_at ,
  is_active ,
  av_status 
)
(select o.id, r.docdata_pdf, r.docnm, r.doctypcd, r.creatdt, r.lastupddt, 'Y', 'Not Scanned'
from etl.select_recs r, etl.organizations o 
where r.imuserbustaxid =  o.tax_identifier
and r.imuserbuslocdunsnmb = o.duns_number);
