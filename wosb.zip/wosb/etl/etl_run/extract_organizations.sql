 \COPY etl.organizations to '/data/prod/wosb/etl/etl_data/organizations.txt' WITH DELIMITER AS '|' NULL as ''
