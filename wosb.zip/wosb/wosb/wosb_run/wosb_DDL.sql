--- Create Tables
CREATE TABLE WOSB.DOCSTATTBL
(
        DOCSTATCD            INTEGER   NULL ,
        DOCSTATDESCTXT       TEXT   NULL ,
        DOCSTATSTARTDT       TIMESTAMP   NULL ,
        DOCSTATENDDT         TIMESTAMP NULL ,
        CREATUSERID          TEXT  NULL ,
        CREATDT              TIMESTAMP   NULL
);


CREATE TABLE WOSB.DOCTBL
(
        DOCID                INTEGER  NULL ,
        TAXID                CHAR(10 )   NULL ,
        DOCTYPCD             INTEGER NULL ,
        IMUSERTYPCD          CHAR(1 )   NULL ,
        DOCSRVNM             CHAR(20 ) NULL ,
        DOCLOCNM             TEXT  NULL ,
        DOCNM                TEXT  NULL ,
        ZIPFILENM            TEXT NULL ,
        DOCSTATCD            INTEGER NULL ,
        DOCSTATDT            TIMESTAMP WITHOUT TIME ZONE   NULL ,
        DUNS                 CHAR(9 ) NULL ,
        CREATUSERNM          TEXT   NULL ,
        LASTUPDUSERNM        TEXT NULL ,
        CREATUSERID          CHAR(15 )   NULL ,
        CREATDT              TIMESTAMP WITHOUT TIME ZONE NULL ,
        LASTUPDUSERID        CHAR(15 )   NULL ,
        LASTUPDDT            TIMESTAMP WITHOUT TIME ZONE NULL ,
        DOCACTVINACTIND      CHAR(1 ) NULL
);


CREATE TABLE WOSB.DOCHSTRYTBL
(
        DOCID                INTEGER  NULL ,
        DOCHSTRYSEQNMB       INTEGER  NULL ,
        IMUSERTYPCD          CHAR(1 )  NULL ,
        DEPTID               CHAR(4 ) NULL ,
        AGNCYID              CHAR(4 ) NULL ,
        CREATUSERNM          TEXT  NULL ,
        CREATUSERID          CHAR(15 )  NULL ,
        CREATDT              TIMESTAMP WITHOUT TIME ZONE  NULL
);


CREATE TABLE WOSB.DOCANSTBL
(
        DOCID                INTEGER  NULL ,
        DOCQTNSNMB           INTEGER  NULL ,
        DOCTYPCD             INTEGER  NULL ,
        DOCQTNSANSWRDESC     TEXT  NULL ,
        CREATUSERNM          TEXT  NULL ,
        LASTUPDTUSERNM       TEXT  NULL ,
        CREATUSERID          CHAR(15 ) NULL ,
        CREATDT              TIMESTAMP WITHOUT TIME ZONE  NULL ,
        LASTUPDUSERID        CHAR(15 ) NULL ,
        LASTUPDDT            TIMESTAMP WITHOUT TIME ZONE  NULL
);


CREATE TABLE WOSB.DOCAUTHTBL
(
        TAXID                CHAR(10 )  NULL ,
        DOCAUTHNMB           INTEGER  NULL ,
        SOLCTNNMB            TEXT  NULL ,
        IMUSERNM             CHAR(32 )  NULL ,
        USERNM               TEXT  NULL ,
        DOCAUTHSTRTDT        TIMESTAMP WITHOUT TIME ZONE NULL ,
        DOCAUTHENDDT         TIMESTAMP WITHOUT TIME ZONE NULL ,
        DEPTID               CHAR(4 )  NULL ,
        AGNCYID              CHAR(4 )  NULL ,
        CREATUSERNM          TEXT  NULL ,
        LASTUPDUSERNM        TEXT  NULL ,
        CREATUSERID          CHAR(15 ) NULL ,
        CREATDT              TIMESTAMP WITHOUT TIME ZONE NULL ,
        LASTUPDUSERID        CHAR(15 )  NULL ,
        LASTUPDDT            TIMESTAMP WITHOUT TIME ZONE NULL
);


CREATE TABLE WOSB.DOCFILEUPLOADTBL
(
        DOCID                INTEGER  NULL ,
        DOCDATA              TEXT NULL ,
        CREATUSERNM          TEXT NULL ,
        CREATUSERID          TEXT NULL ,
        CREATDT              TIMESTAMP WITHOUT TIME ZONE NULL
);


CREATE TABLE WOSB.DOCQTNSTBL
(
        DOCQTNSNMB           INTEGER NULL ,
        DOCTYPCD             INTEGER  NULL ,
        DOCQTNS              TEXT NULL ,
        CREATUSERNM          TEXT NULL ,
        LASTUPDUSERNM        TEXT NULL ,
        CREATUSERID          CHAR(15 )  NULL ,
        CREATDT              TIMESTAMP WITHOUT TIME ZONE NULL ,
        LASTUPDUSERID        CHAR(15 )  NULL ,
        LASTUPDDT            TIMESTAMP WITHOUT TIME ZONE NULL
);


CREATE TABLE WOSB.DOCTBL_BKP
(
        DOCID                INTEGER  NULL ,
        TAXID                CHAR(10 )  NULL ,
        DOCTYPCD             INTEGER NULL ,
        IMUSERTYPCD          CHAR(1 ) NULL ,
        DOCSRVNM             CHAR(20 ) NULL ,
        DOCLOCNM             TEXT NULL ,
        DOCNM                TEXT NULL ,
        ZIPFILENM            TEXT NULL ,
        DOCSTATCD            INTEGER NULL ,
        DOCSTATDT            TIMESTAMP WITHOUT TIME ZONE NULL ,
        DUNS                 CHAR(9 ) NULL ,
        CREATUSERNM          TEXT NOT NULL ,
        LASTUPDUSERNM        TEXT NOT NULL ,
        CREATUSERID          CHAR(15 )  NULL ,
        CREATDT              TIMESTAMP WITHOUT TIME ZONE NULL ,
        LASTUPDUSERID        CHAR(15 )  NULL ,
        LASTUPDDT            TIMESTAMP WITHOUT TIME ZONE NULL ,
        DOCACTVINACTIND      CHAR(1 ) NULL
);

CREATE TABLE WOSB.DOCTYPTBL
(
        DOCTYPCD             INTEGER  NULL ,
        DOCTYPDESCTXT        TEXT NULL ,
        DOCTYPSTARTDT        TIMESTAMP WITHOUT TIME ZONE  NULL ,
        DOCTYPENDDT          TIMESTAMP WITHOUT TIME ZONE NULL ,
        CREATUSERID          CHAR(15 )  NULL ,
        CREATDT              TIMESTAMP WITHOUT TIME ZONE NULL
);



CREATE TABLE WOSB.IMUSERINFOTBL
(
        IMUSERNM             TEXT CONSTRAINT SYS_C00510814 NOT NULL ,
        IMUSERFIRSTNM        TEXT NULL ,
        IMUSERLASTNM         TEXT NULL ,
        IMUSERMIDNM          TEXT NULL ,
        IMUSERBUSEINSSNIND   CHAR(1 )  NULL ,
        IMUSERBUSTAXID       CHAR(9 )  NULL ,
        IMUSERBUSLOCDUNSNMB  CHAR(9 )  NULL
);



CREATE TABLE WOSB.TMPIMUSERINFOTBL
(
        IMUSERNM             TEXT  NULL ,
        IMUSERFIRSTNM        TEXT NULL ,
        IMUSERLASTNM         TEXT NULL ,
        IMUSERMIDNM          TEXT NULL ,
        IMUSERBUSEINSSNIND   CHAR(1 )  NULL ,
        IMUSERBUSTAXID       CHAR(9 )  NULL ,
        IMUSERBUSLOCDUNSNMB  CHAR(9 )  NULL
);

