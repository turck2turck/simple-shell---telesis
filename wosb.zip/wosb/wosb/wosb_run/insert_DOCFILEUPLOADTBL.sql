 \COPY wosb.DOCFILEUPLOADTBL FROM /data/prod/wosb/wosb/wosb_docs/DOCFILEUPLOADTBL_run.txt WITH DELIMITER AS | NULL as '' 
