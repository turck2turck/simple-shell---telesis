 \COPY wosb.DOCTBL FROM '/data/prod/wosb/wosb/wosb_data/DOCTBL_run.txt' WITH DELIMITER AS '>' NULL as '' 
