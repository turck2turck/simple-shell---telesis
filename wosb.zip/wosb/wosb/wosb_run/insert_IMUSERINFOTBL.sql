 \COPY wosb.IMUSERINFOTBL FROM '/data/prod/wosb/wosb/wosb_data/IMUSERINFOTBL_run.txt' WITH DELIMITER AS '|' NULL as '' 
